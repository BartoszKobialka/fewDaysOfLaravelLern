<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ForVer extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'email',
        'password',
        'token'
    ];
    public $timestamps = false;
    protected $table = 'forvers';
}
