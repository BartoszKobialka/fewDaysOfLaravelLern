


<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item['name']); ?></td>
        <td><?php echo e($item['cost']); ?></td>
        <td><?php echo e($item['description']); ?></td>
        <td><button onclick="send('<?php echo e('remove/'.$item['id']); ?>')" class="send btn btn-danger" value="<?php echo e($item['id']); ?>">Usuń z koszyka</button></td>                   
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/cart.blade.php ENDPATH**/ ?>