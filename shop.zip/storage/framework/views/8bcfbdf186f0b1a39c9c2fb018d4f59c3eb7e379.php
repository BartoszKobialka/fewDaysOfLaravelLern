<?php $__env->startComponent('mail::message'); ?>
<h1>Twoje zamówienie</h1>
<table class="table table-dark mt-5">
    <thead>
      <tr>
        <th scope="col">Nazwa</th>
        <th scope="col">Cena</th>
        <th scope="col">Opis</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item['name']); ?></td>
            <td><?php echo e($item['cost']); ?></td>
            <td><?php echo e($item['description']); ?></td>                
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\xampp\htdocs\shop\resources\views/emails/order.blade.php ENDPATH**/ ?>