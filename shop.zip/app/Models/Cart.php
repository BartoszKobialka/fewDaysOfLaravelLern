<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Cart extends Model
{
    use HasFactory;
    public $table = 'cart';

    public $fillable = ['users_mail', 'product_id'];
    public $timestamps = false;

    
    public function products($u_email)
    {
        $prod = DB::table($this->table)->leftJoin('products', 'products.id', '=', 'cart.product_id')->where('user_email', '=', $u_email)->select('products.*')->get();
        return $prod;
    }
}
