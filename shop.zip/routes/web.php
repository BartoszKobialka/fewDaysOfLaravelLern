<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PagesController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/login', [PagesController::class, 'login']);
Route::post('user', [PagesController::class, 'userLogin']);
Route::get('/main', [PagesController::class, 'main']);
Route::get('logout', [PagesController::class, 'logout']);
Route::get('/main/add/{id}', [PagesController::class, 'addToCart']);
Route::get('/main/remove/{id}', [PagesController::class, 'removeFromCart']);
Route::get('/main/cart', [PagesController::class, 'cart']);
Route::post('addprod', [PagesController::class, 'addProduct']);
Route::post('/userregister', [PagesController::class, 'userRegister']);
Route::post('/mail/order', [PagesController::class, 'orderMail']);
Route::get('/register', [PagesController::class, 'register']);
Route::get('/verify/{email}/{token}', [PagesController::class, 'verify']);