@component('mail::message')
<h1>Dziękujemy za rejestrację,</h1>
<h3>Teraz tylko zweryfikuj swój e-mail.</h3>

@component('mail::button', ['url' => 'http://localhost:8000/verify/'.$email.'/'.$token])
Zweryfikuj
@endcomponent

@endcomponent
